<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require 'vendor/autoload.php';
use Aws\S3\S3Client;
use Aws\Exception\AwsException;

include 'conexion.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre = $_POST['nombre'];
    $telefono = $_POST['telefono'];
    $direccion = $_POST['direccion'];
    $correo = $_POST['correo'];

    // Configuración de S3
    $bucketName = 's3acr2024';
    $s3 = new S3Client([
        'version' => 'latest',
        'region'  => 'us-east-1',  // Asegúrate de que esta es la región correcta para tu bucket
    ]);

    $ruta_foto = null;
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] == 0) {
        $foto = $_FILES['foto'];

        list($ancho_original, $alto_original) = getimagesize($foto['tmp_name']);
        $ancho_destino = 138;
        $alto_destino = 177;

        $imagen_destino = imagecreatetruecolor($ancho_destino, $alto_destino);
        $imagen_origen = imagecreatefromstring(file_get_contents($foto['tmp_name']));
        imagecopyresampled($imagen_destino, $imagen_origen, 0, 0, 0, 0, $ancho_destino, $alto_destino, $ancho_original, $alto_original);

        $nombre_archivo = uniqid() . '.jpg';
        $ruta_temporal = '/tmp/' . $nombre_archivo;
        imagejpeg($imagen_destino, $ruta_temporal);

        imagedestroy($imagen_origen);
        imagedestroy($imagen_destino);

        // Subir la imagen a S3
        try {
            $result = $s3->putObject([
                'Bucket' => $bucketName,
                'Key'    => 'fotos/' . $nombre_archivo,  // Ruta dentro del bucket
                'SourceFile' => $ruta_temporal,
        //        'ACL'    => 'public-read', // Esto hace que la imagen sea pública
            ]);

            // Obtener la URL pública de la imagen
            $ruta_foto = $result['ObjectURL'];

            // Eliminar el archivo temporal después de subirlo a S3
            unlink($ruta_temporal);
        } catch (AwsException $e) {
            echo "Error subiendo a S3: " . $e->getMessage();
            exit;
        }
    }

    try {
        $sql = "INSERT INTO clientes (nombre, telefono, direccion, correo, foto) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(1, $nombre);
        $stmt->bindParam(2, $telefono);
        $stmt->bindParam(3, $direccion);
        $stmt->bindParam(4, $correo);
        $stmt->bindParam(5, $ruta_foto);

        $stmt->execute();

        // Redirigir a index.php después de agregar el cliente
        header("Location: index.php");
        exit();
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar Cliente</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <h1>Agregar Cliente</h1>

    <form method="POST" action="agregar.php" enctype="multipart/form-data">
        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" required>

        <label for="telefono">Teléfono:</label>
        <input type="text" id="telefono" name="telefono" required>

        <label for="direccion">Dirección:</label>
        <input type="text" id="direccion" name="direccion" required>

        <label for="correo">Correo Electrónico:</label>
        <input type="email" id="correo" name="correo" required>

        <label for="foto">Foto:</label>
        <input type="file" id="foto" name="foto" style="display: none;" required>
        <label for="foto" class="btn btn-subir">Seleccionar archivo</label>
        <span id="file-chosen" style="margin-left: 10px; font-size: 14px; color: #28a745;">Ningún archivo seleccionado</span>

        <button type="submit" class="btn btn-agregar">Agregar Cliente</button>
    </form>

    <script>
        const fileInput = document.getElementById('foto');
        const fileChosen = document.getElementById('file-chosen');

        fileInput.addEventListener('change', function(){
            if (fileInput.files.length > 0) {
                fileChosen.textContent = 'Archivo seleccionado: ' + fileInput.files[0].name;
            } else {
                fileChosen.textContent = 'Ningún archivo seleccionado';
            }
        });
    </script>

    <!-- Botón Volver -->
    <div style="margin-top: 20px;">
        <a href="index.php" class="btn btn-volver">Volver</a>
    </div>
</body>
</html>
