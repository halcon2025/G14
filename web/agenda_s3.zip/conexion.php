<?php
$host = 'dbpospru.cuxarchhfvl1.us-east-1.rds.amazonaws.com';
$db = 'agenda_db2';
$user = 'agenda_user2';
$pass = 'Labpassword';
try {
    $conn = new PDO("pgsql:host=$host;dbname=$db", $user, $pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error en la conexión a la base de datos: " . $e->getMessage());
}
?>
