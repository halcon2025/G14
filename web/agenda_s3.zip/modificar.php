<?php

require 'vendor/autoload.php';  // Asegúrate de cargar las dependencias

use Aws\S3\S3Client;
use Aws\Exception\AwsException;



include 'conexion.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    try {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            $nombre = $_POST['nombre'];
            $telefono = $_POST['telefono'];
            $direccion = $_POST['direccion'];
            $correo = $_POST['correo'];

            // Inicializar la variable para la ruta de la nueva foto
            $ruta_foto = null;

            // Verificar si se subió una nueva foto
            if (isset($_FILES['foto']) && $_FILES['foto']['error'] == 0) {
                $foto = $_FILES['foto'];

                // Redimensionar la imagen al tamaño de una foto de carnet (3.5cm x 4.5cm)
                list($ancho_original, $alto_original) = getimagesize($foto['tmp_name']);
                $ancho_destino = 138; // 3.5 cm en píxeles (asumiendo 96 dpi)
                $alto_destino = 177;  // 4.5 cm en píxeles (asumiendo 96 dpi)

                $imagen_destino = imagecreatetruecolor($ancho_destino, $alto_destino);
                $imagen_origen = imagecreatefromstring(file_get_contents($foto['tmp_name']));
                imagecopyresampled($imagen_destino, $imagen_origen, 0, 0, 0, 0, $ancho_destino, $alto_destino, $ancho_original, $alto_original);

		// Guardar la imagen redimensionada en la carpeta temporal
                $nombre_archivo = uniqid() . '.jpg';
                $ruta_temporal = '/tmp/' . $nombre_archivo;
                imagejpeg($imagen_destino, $ruta_temporal);

                imagedestroy($imagen_origen);
                imagedestroy($imagen_destino);

 		// Subir la imagen a S3
                $bucketName = 's3acr2024';
                $s3 = new S3Client([
                    'version' => 'latest',
                    'region'  => 'us-east-1',
                ]);

                try {
                    $result = $s3->putObject([
                        'Bucket' => $bucketName,
                        'Key'    => 'fotos/' . $nombre_archivo,
                        'SourceFile' => $ruta_temporal,
                    ]);

                    // Obtener la URL pública de la imagen
                    $ruta_foto = $result['ObjectURL'];

                    // Eliminar el archivo temporal después de subirlo a S3
                    unlink($ruta_temporal);
                } catch (AwsException $e) {
                    echo "Error subiendo a S3: " . $e->getMessage();
                    exit;
                }




            }

            // Preparar la consulta de actualización
            if ($ruta_foto) {
                // Si se subió una nueva foto, se incluye en la actualización
                $stmt = $conn->prepare("UPDATE clientes SET nombre=?, telefono=?, direccion=?, correo=?, foto=? WHERE id=?");
                $params = [$nombre, $telefono, $direccion, $correo, $ruta_foto, $id];
            } else {
                // Si no se subió una nueva foto, se omite en la actualización
                $stmt = $conn->prepare("UPDATE clientes SET nombre=?, telefono=?, direccion=?, correo=? WHERE id=?");
                $params = [$nombre, $telefono, $direccion, $correo, $id];
            }

            // Ejecutar la consulta
            if ($stmt->execute($params)) {
                header('Location: index.php');
                exit;
            } else {
                echo "No se pudo modificar el cliente.";
            }
        } else {
            // Obtener datos del cliente actual
            $stmt = $conn->prepare("SELECT * FROM clientes WHERE id=?");
            $stmt->execute([$id]);
            $cliente = $stmt->fetch();
        }
    } catch (PDOException $e) {
        echo "Error en la base de datos: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modificar Cliente</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <h1>Modificar Cliente</h1>
    <form method="POST" enctype="multipart/form-data">
        <input type="hidden" name="id" value="<?php echo htmlspecialchars($cliente['id']); ?>">

        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" value="<?php echo htmlspecialchars($cliente['nombre']); ?>" required><br>

        <label for="telefono">Teléfono:</label>
        <input type="text" id="telefono" name="telefono" value="<?php echo htmlspecialchars($cliente['telefono']); ?>"><br>

        <label for="direccion">Dirección:</label>
        <input type="text" id="direccion" name="direccion" value="<?php echo htmlspecialchars($cliente['direccion']); ?>"><br>

        <label for="correo">Correo Electrónico:</label>
        <input type="email" id="correo" name="correo" value="<?php echo htmlspecialchars($cliente['correo']); ?>"><br>

        <label for="foto">Foto:</label>
        <input type="file" id="foto" name="foto" style="display: none;">
        <label for="foto" class="btn btn-subir">Seleccionar archivo</label>
        <span id="file-chosen" style="margin-left: 10px; font-size: 14px; color: #28a745;">Ningún archivo seleccionado</span> <!-- Mensaje que muestra el archivo seleccionado -->

        <button type="submit" class="btn btn-agregar">Modificar</button>
    </form>
    <a href="index.php" class="btn">Volver</a>

    <script>
        const fileInput = document.getElementById('foto');
        const fileChosen = document.getElementById('file-chosen');

        fileInput.addEventListener('change', function(){
            if (fileInput.files.length > 0) {
                fileChosen.textContent = 'Archivo seleccionado: ' + fileInput.files[0].name;
            } else {
                fileChosen.textContent = 'Ningún archivo seleccionado';
            }
        });
    </script>
</body>

</html>

