<?php
include 'conexion.php';

try {
    $stmt = $conn->query("SELECT * FROM clientes");
    $clientes = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agenda de Clientes</title>
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
    <h1>Agenda de Clientes</h1>

    <!-- Botones de Acción -->
    <div style="margin-bottom: 20px;">
        <a href="agregar.php" class="btn btn-agregar" style="display: block; margin-bottom: 10px;">Agregar Cliente</a>
        <a href="consultar.php" class="btn btn-agregar" style="display: block;">Consultar Cliente</a>
    </div>

    <?php if (!empty($clientes)): ?>
    <table>
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Teléfono</th>
                <th>Dirección</th>
                <th>Correo Electrónico</th>
                <th>Foto</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($clientes as $cliente): ?>
            <tr>
                <td><?php echo htmlspecialchars($cliente['nombre']); ?></td>
                <td><?php echo htmlspecialchars($cliente['telefono']); ?></td>
                <td><?php echo htmlspecialchars($cliente['direccion']); ?></td>
                <td><?php echo htmlspecialchars($cliente['correo']); ?></td>
                <td>
                    <?php if (!empty($cliente['foto'])): ?>
                        <img src="<?php echo htmlspecialchars($cliente['foto']); ?>" alt="Foto de <?php echo htmlspecialchars($cliente['nombre']); ?>" style="width:100px; height:130px;">
                    <?php else: ?>
                        No disponible
                    <?php endif; ?>
                </td>
                <td>
                    <a href="modificar.php?id=<?php echo $cliente['id']; ?>" class="btn btn-modificar">Modificar</a>
                    <a href="eliminar.php?id=<?php echo $cliente['id']; ?>" class="btn btn-eliminar">Eliminar</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php else: ?>
        <p>No hay clientes registrados.</p>
    <?php endif; ?>

    <script src="js/scripts.js"></script>
</body>
</html>
