<?php
include 'conexion.php';  // Incluir el archivo de conexión

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    try {
        // Preparar la consulta de eliminación
        $stmt = $conn->prepare("DELETE FROM clientes WHERE id=?");

        // Ejecutar la consulta
        if ($stmt->execute([$id])) {
            header('Location: index.php');  // Redirigir de vuelta a la página principal
            exit;
        } else {
            echo "No se pudo eliminar el cliente.";
        }
    } catch (PDOException $e) {
        echo "Error en la base de datos: " . $e->getMessage();
    }
} else {
    echo "ID de cliente no proporcionado.";
}
?>
