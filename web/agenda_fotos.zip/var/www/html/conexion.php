<?php
$host = 'bdposgress.copx9chwrjse.us-east-1.rds.amazonaws.com';
$db = 'agenda_db';
$user = 'agenda_user';
$pass = 'lab-password';
try {
    $conn = new PDO("pgsql:host=$host;dbname=$db", $user, $pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error en la conexión a la base de datos: " . $e->getMessage());
}
?>
