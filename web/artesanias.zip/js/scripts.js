// Cambiar color del título al pasar el cursor
document.getElementById('titulo').addEventListener('mouseover', function() {
    this.style.color = '#ffc107'; // Amarillo dorado
});

document.getElementById('titulo').addEventListener('mouseout', function() {
    this.style.color = '#fff'; // Vuelve al color blanco
});
