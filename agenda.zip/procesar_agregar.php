<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include 'conexion.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre = $_POST['nombre'];
    $telefono = $_POST['telefono'];
    $direccion = $_POST['direccion'];
    $correo = $_POST['correo'];

    // Definir la ruta de la carpeta de imágenes
    $carpeta_destino = '/var/www/html/agenda2/fotos/';

    // Asegurarse de que la carpeta exista
    if (!file_exists($carpeta_destino)) {
        mkdir($carpeta_destino, 0777, true);
    }

    $ruta_foto = null;
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] == 0) {
        $foto = $_FILES['foto'];

        // Redimensionar la imagen al tamaño de una foto de carnet (3.5cm x 4.5cm)
        list($ancho_original, $alto_original) = getimagesize($foto['tmp_name']);
        $ancho_destino = 138; // 3.5 cm en píxeles (asumiendo 96 dpi)
        $alto_destino = 177;  // 4.5 cm en píxeles (asumiendo 96 dpi)

        $imagen_destino = imagecreatetruecolor($ancho_destino, $alto_destino);
        $imagen_origen = imagecreatefromstring(file_get_contents($foto['tmp_name']));
        imagecopyresampled($imagen_destino, $imagen_origen, 0, 0, 0, 0, $ancho_destino, $alto_destino, $ancho_original, $alto_original);

        // Guardar la imagen redimensionada en la carpeta
        $nombre_archivo = uniqid() . '.jpg';
        $ruta_foto = $carpeta_destino . $nombre_archivo;
        imagejpeg($imagen_destino, $ruta_foto);

        imagedestroy($imagen_origen);
        imagedestroy($imagen_destino);

        // Guardar la ruta relativa en la base de datos
        $ruta_foto = 'fotos/' . $nombre_archivo;
    }

    try {
        $sql = "INSERT INTO clientes (nombre, telefono, direccion, correo, foto) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(1, $nombre);
        $stmt->bindParam(2, $telefono);
        $stmt->bindParam(3, $direccion);
        $stmt->bindParam(4, $correo);
        $stmt->bindParam(5, $ruta_foto);

        $stmt->execute();

        echo "Cliente agregado exitosamente.";
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
}
?>
