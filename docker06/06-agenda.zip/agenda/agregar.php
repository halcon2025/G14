<?php
include 'conexion.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
 $nombre = $_POST['nombre'];
 $telefono = $_POST['telefono'];
 $direccion = $_POST['direccion'];
 $correo = $_POST['correo'];
 try {
 $stmt = $conn->prepare("INSERT INTO clientes (nombre, telefono, direccion, correo) VALUES (?, 
?, ?, ?)");
 if ($stmt->execute([$nombre, $telefono, $direccion, $correo])) {
 header('Location: index.php');
 exit;
 } else {
 echo "No se pudo agregar el cliente.";
 }
 } catch (PDOException $e) {
 echo "Error en la base de datos: " . $e->getMessage();
 }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <title>Agregar Cliente</title>
 <link rel="stylesheet" href="css/styles.css">
</head>
<body>
 <h1>Agregar Cliente</h1>
 <form method="POST">
 <label for="nombre">Nombre:</label>
 <input type="text" id="nombre" name="nombre" required><br>
 <label for="telefono">Teléfono:</label>
 <input type="text" id="telefono" name="telefono"><br>
 <label for="direccion">Dirección:</label>
 <input type="text" id="direccion" name="direccion"><br>
 <label for="correo">Correo Electrónico:</label>
 <input type="email" id="correo" name="correo"><br>
 <button type="submit" class="btn">Agregar</button>
 </form>
 <a href="index.php" class="btn">Volver</a>
</body>
</html>
