<?php
include 'conexion.php';

if (isset($_GET['id'])) {
 $id = $_GET['id'];
 try {
 if ($_SERVER['REQUEST_METHOD'] == 'POST') {
 $nombre = $_POST['nombre'];
 $telefono = $_POST['telefono'];
 $direccion = $_POST['direccion'];
 $correo = $_POST['correo'];
 // Preparar la consulta de actualización
 $stmt = $conn->prepare("UPDATE clientes SET nombre=?, telefono=?, direccion=?, correo=? 
WHERE id=?");
 // Ejecutar la consulta
 if ($stmt->execute([$nombre, $telefono, $direccion, $correo, $id])) {
 header('Location: index.php');
 exit;
 } else {
 echo "No se pudo modificar el cliente.";
 }
 } else {
 // Obtener datos del cliente actual
 $stmt = $conn->prepare("SELECT * FROM clientes WHERE id=?");
 $stmt->execute([$id]);
 $cliente = $stmt->fetch();
 }
 } catch (PDOException $e) {
 echo "Error en la base de datos: " . $e->getMessage();
 }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <title>Modificar Cliente</title>
 <link rel="stylesheet" href="css/styles.css">
</head>
<body>
 <h1>Modificar Cliente</h1>
 <form method="POST">
 <input type="hidden" name="id" value="<?php echo htmlspecialchars($cliente['id']); ?>">
 <label for="nombre">Nombre:</label>
 <input type="text" id="nombre" name="nombre" value="<?php echo 
htmlspecialchars($cliente['nombre']); ?>" required><br>
 <label for="telefono">Teléfono:</label>
 <input type="text" id="telefono" name="telefono" value="<?php echo 
htmlspecialchars($cliente['telefono']); ?>"><br>
 <label for="direccion">Dirección:</label>
 <input type="text" id="direccion" name="direccion" value="<?php echo 
htmlspecialchars($cliente['direccion']); ?>"><br>
 <label for="correo">Correo Electrónico:</label>
 <input type="email" id="correo" name="correo" value="<?php echo 
htmlspecialchars($cliente['correo']); ?>"><br>
 <button type="submit" class="btn">Modificar</button>
</form>
 <a href="index.php" class="btn">Volver</a>
</body>
</html>
