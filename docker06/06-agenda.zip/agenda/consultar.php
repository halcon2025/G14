<?php
include 'conexion.php';

$clientes = [];

if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['nombre'])) {
    $nombre = $_GET['nombre'];
    try {
        // Consulta SQL para buscar nombres que comiencen con las letras proporcionadas o coincidan completamente
        $stmt = $conn->prepare("SELECT * FROM clientes WHERE nombre ILIKE ?");
        $stmt->execute([$nombre . '%']);  // ILIKE es insensible a mayúsculas y minúsculas
        $clientes = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        echo "Error en la base de datos: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consultar Clientes</title>
    <link rel="stylesheet" href="css/styles.css">
    <style>
        .no-result {
            color: #ff0000;
            font-weight: bold;
            position: absolute;
            top: 20px;
            right: 20px;
            background-color: #fff0f0;
            padding: 10px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body>
    <h1>Consultar Clientes</h1>

    <form method="GET" action="consultar.php">
        <label for="nombre">Nombre (o primeras letras):</label>
        <input type="text" id="nombre" name="nombre" required>
        <button type="submit" class="btn btn-agregar">Buscar</button>
    </form>

    <?php
    include 'conexion.php';

    $clientes = [];
    $showNoResultMessage = false;

    if ($_SERVER['REQUEST_METHOD'] == 'GET' && !empty($_GET['nombre'])) {
        $nombre = $_GET['nombre'];

        try {
            // Consulta SQL para buscar nombres que comiencen con las letras proporcionadas o coincidan completamente
            $stmt = $conn->prepare("SELECT * FROM clientes WHERE nombre ILIKE ?");
            $stmt->execute([$nombre . '%']);  // ILIKE es insensible a mayúsculas y minúsculas
            $clientes = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Mostrar mensaje solo si no hay resultados
            if (empty($clientes)) {
                $showNoResultMessage = true;
            }
        } catch (PDOException $e) {
            echo "Error en la base de datos: " . $e->getMessage();
        }
    }
    ?>

    <?php if ($showNoResultMessage): ?>
        <div class="no-result">No se encontraron clientes con ese criterio de búsqueda.</div>
    <?php endif; ?>

    <?php if (!empty($clientes)): ?>
        <h2>Resultados de la búsqueda:</h2>
        <table>
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Teléfono</th>
                    <th>Dirección</th>
                    <th>Correo Electrónico</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($clientes as $cliente): ?>
                <tr>
                    <td><?php echo htmlspecialchars($cliente['nombre']); ?></td>
                    <td><?php echo htmlspecialchars($cliente['telefono']); ?></td>
                    <td><?php echo htmlspecialchars($cliente['direccion']); ?></td>
                    <td><?php echo htmlspecialchars($cliente['correo']); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>

    <!-- Botón Volver -->
    <div style="text-align: left; margin-top: 20px;">
        <a href="index.php" class="btn btn-agregar">Volver</a>
    </div>

</body>
</html>
