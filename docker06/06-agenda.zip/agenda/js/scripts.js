document.addEventListener('DOMContentLoaded', function () {
 // Confirmar eliminación de cliente
 const deleteLinks = document.querySelectorAll('a.btn-eliminar');
 deleteLinks.forEach(function (link) {
 link.addEventListener('click', function (event) {
 event.preventDefault(); // Evitar la acción predeterminada de inmediato
 const confirmed = confirm('¿Estás seguro de que deseas eliminar este cliente?');
 if (confirmed) {
 window.location.href = this.href; // Redirigir solo si se confirma
 }
 });
 });
 // Validación del formulario
 const form = document.querySelector('form');
 if (form) {
 form.addEventListener('submit', function (event) {
 const nombre = document.getElementById('nombre').value.trim();
 if (nombre === '') {
 alert('El nombre es obligatorio.');
 event.preventDefault(); // Evitar el envío del formulario si el nombre está vacío
 }
 });
 }
});
